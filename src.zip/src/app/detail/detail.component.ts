import { Component, OnInit } from '@angular/core';
import { EmployeService } from '../services/employe.service' ; 
import { Employe } from '../employe' ; 
import { ActivatedRoute, Router } from '@angular/router' ; 

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  employe : Employe ; 
  
  id : number ; 
    
  constructor(private route : ActivatedRoute, private router : Router, private employe_service : EmployeService) { }

  ngOnInit() {
      
      this.id = this.route.snapshot.params['id'] ; 
      
      this.getEmployeDetails(this.id) ; 
  }
    
  getEmployeDetails(id : number)
  {
    this.employe_service.getEmploye(id).subscribe(
        data => {
            console.log(data) ; 
            this.employe = data ; 
        } , 
        err => {
            console.log(err) ; 
        }
    ) ;    
  }

  goToList()
  {
    this.router.navigate(["/employeList"]) ;       
  }
}
