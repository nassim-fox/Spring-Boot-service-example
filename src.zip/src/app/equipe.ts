
export class Equipe
{
    id : number ; 
    nom :string ; 
}