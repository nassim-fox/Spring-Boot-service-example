import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeListSearchComponent } from './employe-list-search.component';

describe('EmployeListSearchComponent', () => {
  let component: EmployeListSearchComponent;
  let fixture: ComponentFixture<EmployeListSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeListSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeListSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
