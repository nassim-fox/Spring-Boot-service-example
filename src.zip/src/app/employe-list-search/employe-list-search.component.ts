import { Component, OnInit } from '@angular/core';
import { EmployeService } from '../services/employe.service' ; 
import { Employe } from '../employe' ; 
import { Observable } from 'rxjs' ; 
import { ActivatedRoute , Router } from '@angular/router'

@Component({
  selector: 'app-employe-list-search',
  templateUrl: './employe-list-search.component.html',
  styleUrls: ['./employe-list-search.component.css']
})
export class EmployeListSearchComponent implements OnInit {

  employeList : Employe[] ; 
  nom : string ; 
    
  constructor(private route: ActivatedRoute, private router: Router, private employe_service : EmployeService) { 
  

  }

  ngOnInit() {
      
      this.nom = this.route.snapshot.params['nom'];
      
      console.log("le nom reçu : "+this.nom) ; 
      
      this.getsearch(this.nom) ;
      
       

  }
   

    getsearch(nom : string)
    {
        this.employe_service.getEmployeByNom(nom).subscribe(
        data => {
            console.log(data) ; 
            this.employeList = data ; 
        } , 
        err => {
            console.log(err) ; 
        }
      ) ; 
    }
}
