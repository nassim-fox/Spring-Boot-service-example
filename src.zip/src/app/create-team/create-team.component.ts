import { Component, OnInit } from '@angular/core';
import { Employe } from '../employe';
import { Equipe } from '../equipe';
import { EquipeService } from '../services/equipe-service.service';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'create-team',
  templateUrl: './create-team.component.html',
  styleUrls: ['./create-team.component.css']
})
export class CreateTeamComponent implements OnInit {

    
nb_equipe : number ; 
nb_employe : number ; 
    
  constructor(private route: ActivatedRoute,private router: Router,
    private equipeService: EquipeService) { }
    
  ngOnInit() {
  }
    
  onSubmit()
  {
  
    console.log(this.nb_equipe+" "+this.nb_employe) ; 
      
      // suppression et après avoir fini création
      this.equipeService.equipeDelete().subscribe(
        data => {console.log(data);  
                 //si succes alors création 
                 this.equipeService.equipeCreate(this.nb_equipe,this.nb_employe).subscribe(
        data => console.log(data),
        error => console.log(error)
        );
       
       },
        error => console.log(error)); 
   
     
     
      
      
  }

    gotoList() {
        this.router.navigate(['/employeList']);
    }
}
