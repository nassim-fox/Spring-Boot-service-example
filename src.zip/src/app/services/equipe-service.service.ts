import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http' ;
import { Employe } from '../employe' ; 
import { Equipe } from '../equipe' ;
import { Observable } from 'rxjs' ; 

@Injectable({
  providedIn: 'root'
})
export class EquipeService {

  private create_url = "http://localhost:8080/equipesCreate/" ; 
  private delete_url = "http://localhost:8080/equipesDelete/" ;
    
  constructor(private http:HttpClient) { }
   
  equipeCreate(nb_equipe : number,nb_employe : number) :
    Observable<Employe>
  {
      console.log("create equipe") ; 
      
       return this.http.post<Employe>(this.create_url+"/"+nb_equipe+"/"+nb_employe,"") ; 
      
  }
    
 
  equipeDelete() : Observable<string>
  {
        console.log("delete equipe") ; 

        return this.http.delete<string>(this.delete_url) ;   
  }
    
  getEquipeList() : Observable<Equipe[]>
  {
   
      return this.http.get<Equipe[]>("http://localhost:8080/listEquipe") ; 
  }
  
}
