import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http' ;
import { Employe } from '../employe' ; 
import { Observable } from 'rxjs' ; 

@Injectable({
  providedIn: 'root'
})
export class EmployeService {

  private url = "http://localhost:8080/listEmploye/" ; 
    
  constructor(private http:HttpClient) { }
   
  getEmploye(id : number) : Observable <Employe>
  {
       return this.http.get<Employe>(this.url+id)  
  }
    
  getEmployeByNom(nom : string) : Observable <Employe[]>
  {
       return this.http.get<Employe[]>(this.url+"/search/"+nom)  
  }
    
  getEmployeList(): Observable <Employe[]> 
  {
      return this.http.get<Employe[]>(this.url) ; 
  }
    
  saveEmploye(employe : Employe): Observable<Employe> 
  {
      return this.http.post<Employe>(this.url,employe) ; 
  }

  updateEmploye(id : number, employe : Employe): Observable<Employe>
  {
      return this.http.put<Employe>(this.url+id,employe) ; 
  }

  deleteEmploye(id : number): Observable<string>
  {
      return this.http.delete<string>(this.url+id) ;   
  }
}
