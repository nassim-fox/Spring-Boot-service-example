import { TestBed } from '@angular/core/testing';

import { EquipeServiceService } from './equipe-service.service';

describe('EquipeServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EquipeServiceService = TestBed.get(EquipeServiceService);
    expect(service).toBeTruthy();
  });
});
