import { Component, OnInit } from '@angular/core';
import { Employe } from '../employe';
import { Router } from '@angular/router';
import { EmployeService } from '../services/employe.service';
@Component({
selector: 'app-create-employe',
templateUrl: './create-employe.component.html',
styleUrls: ['./create-employe.component.css']
})
export class CreateEmployeComponent implements OnInit {
    
    employe: Employe = new Employe();
    
    submitted = false;
   
    constructor(private employeService: EmployeService,
                private router: Router) { }
    
    ngOnInit() {
    
    }
    
    newEmploye(): void {
        this.submitted = false;
        this.employe = new Employe();
    }

    save() {
        this.employeService.saveEmploye(this.employe)
        .subscribe(
        data => console.log(data),
        error => console.log(error)
        );
        this.employe = new Employe();
        this.gotoList();
    }
    
    onSubmit() {
        this.submitted = true;
        this.save();
    }
    gotoList() {
        this.router.navigate(['/employeList']);
    }
    
}