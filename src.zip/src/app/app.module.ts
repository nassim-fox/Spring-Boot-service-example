import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { navComponent } from './nav/nav.component';
import { EmployeListComponent } from './employe-list/employe-list.component' ; 
import { HttpClientModule } from '@angular/common/http';
import { CreateEmployeComponent } from './create-employe/create-employe.component' ; 
import { FormsModule} from '@angular/forms';
import { UpdateEmployeComponent } from './update-employe/update-employe.component' ; 
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { SearchComponent } from './search/search.component';
import { EmployeListSearchComponent } from './employe-list-search/employe-list-search.component';
import { DetailComponent } from './detail/detail.component';
import { CreateTeamComponent } from './create-team/create-team.component';
import { EquipeListComponent } from './equipe-list/equipe-list.component' ;



@NgModule({
  declarations: [
    AppComponent,
    EmployeListComponent,
    CreateEmployeComponent,
    UpdateEmployeComponent,
    SearchComponent,
    EmployeListSearchComponent,
    DetailComponent,
    CreateTeamComponent,
    EquipeListComponent 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule , 
    HttpClientModule, 
    AngularFontAwesomeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
