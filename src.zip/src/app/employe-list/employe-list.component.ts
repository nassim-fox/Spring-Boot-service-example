import { Component, OnInit } from '@angular/core';
import { EmployeService } from '../services/employe.service' ; 
import { Employe } from '../employe' ; 
import { Observable } from 'rxjs' ; 
import { ActivatedRoute , Router } from '@angular/router'

@Component({
  selector: 'app-employe-list',
  templateUrl: './employe-list.component.html',
  styleUrls: ['./employe-list.component.css']
})
export class EmployeListComponent implements OnInit {

  employeList : Employe[] ; 
  nom : string ; 
    
  constructor(private route: ActivatedRoute, private router: Router, private employe_service : EmployeService) { }

  ngOnInit() {
     
      this.reloadData() ; 
  }
    
    
  reloadData()
  {
      this.employe_service.getEmployeList().subscribe(
        data => {
            console.log(data) ; 
            this.employeList = data ; 
        } , 
        err => {
            console.log(err) ; 
        }
      ) ; 
      
  }
    
    deleteEmploye(id: number) {
        
        this.employe_service.deleteEmploye(id).subscribe(
        data => {console.log(data); this.reloadData(); },
        error => console.log(error));
    }
    
    updateEmploye(id: number){
        this.router.navigate(['update', id]);
    
            
    }
    
    getEmploye(id: number){
        this.router.navigate(['detail', id]) ; 
        
    }

   
}
