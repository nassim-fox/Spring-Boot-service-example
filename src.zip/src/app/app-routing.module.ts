import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeListComponent } from './employe-list/employe-list.component' ;
import { EmployeListSearchComponent } from './employe-list-search/employe-list-search.component' ;
import { CreateEmployeComponent } from './create-employe/create-employe.component' ; 
import { UpdateEmployeComponent } from './update-employe/update-employe.component' ; 
import { DetailComponent } from './detail/detail.component' ; 
import { CreateTeamComponent } from './create-team/create-team.component' ; 
import { EquipeListComponent } from './equipe-list/equipe-list.component' ;


const routes: Routes = [
    
    { path : 'employeList', component : EmployeListComponent } ,
    { path : 'employeListSearch/:nom', component : EmployeListSearchComponent } ,
     { path : 'equipeList', component : EquipeListComponent } ,
    { path : 'add', component : CreateEmployeComponent } ,
    { path : 'update/:id' , component : UpdateEmployeComponent} ,
    { path : 'detail/:id', component : DetailComponent }
    ,   
    { path : 'add-equipe', component : CreateTeamComponent }

    ,
    { path : '', redirectTo :'employe', pathMatch : 'full'} 
    
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
