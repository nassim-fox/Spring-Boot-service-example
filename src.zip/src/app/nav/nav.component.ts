

import { Component } from '@angular/core' ; 


@Component({
    selector : 'nav', 
    templateUrl : 'nav.component.html',
    styleUrls : ['nav.component.css']
}) 

export class navComponent
{
    navbarCollapsed = true;

    toggleNavbarCollapsing() {
        this.navbarCollapsed = !this.navbarCollapsed;
    }
}