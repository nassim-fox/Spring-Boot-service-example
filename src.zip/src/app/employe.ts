
export class Employe
{
    id : number ; 
    nom :string ; 
    prenom : string ;
    email : string ; 
    id_equipe : string ; 
}