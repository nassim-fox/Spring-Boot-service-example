import { Component, OnInit, Input } from '@angular/core';
import { Employe } from '../employe';
import { EmployeService } from '../services/employe.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
selector: 'search',
templateUrl: './search.component.html',
styleUrls: ['./search.component.css']
})

export class SearchComponent implements OnInit {

    @Input() fromParent : number ; 
    k : string[] = ["a","b","c"] ; 
    
    nom: string ;
    employe: Employe;
    
    constructor(private route: ActivatedRoute,private router: Router,
    private employeService: EmployeService) { }
    
    ngOnInit() {

        
        }
    
    search(nom: string){
        this.router.navigate(['/employeListSearch', nom]);
    
            
    }
   
    onSubmit() {
        console.log("submited !!! ") ; 
        console.log("le nom est : "+this.nom) ; 
        this.search(this.nom);
        
    }
    
    gotoList() {
        this.router.navigate(['/employeList']);
    }
    }
