import { Component, OnInit } from '@angular/core';
import { Equipe } from '../equipe' ; 
import { Employe } from '../employe' ; 
import { EquipeService } from '../services/equipe-service.service' ;

@Component({
  selector: 'app-equipe-list',
  templateUrl: './equipe-list.component.html',
  styleUrls: ['./equipe-list.component.css']
})
export class EquipeListComponent implements OnInit {

  private equipeList : Equipe[] ; 
    
  constructor(private equipe_service : EquipeService) { }

  ngOnInit() {
      this.reloadData() ; 
  }

  reloadData()
  {
      this.equipe_service.getEquipeList().subscribe(
        data => {
            console.log(data) ; 
            this.equipeList = data ; 
        } , 
        err => {
            console.log(err) ; 
        }
      ) ; 
      
  }
}
